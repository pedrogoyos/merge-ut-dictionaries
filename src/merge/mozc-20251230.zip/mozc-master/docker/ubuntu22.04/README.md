# docker/ubuntu22.04 (Deprecated)

 * [`Dockerfile`](./Dockerfile)

⚠️ `Dockerfile` provided in this directory is deprecated. See the following documents on how to build Mozc for Linux desktop or Android.

* [How to build Mozc for Android](../../docs/build_mozc_for_android.md): for Android library (`libmozc.so`)
* [How to build Mozc for Linux](../../docs/build_mozc_for_linux.md): for Linux desktop
